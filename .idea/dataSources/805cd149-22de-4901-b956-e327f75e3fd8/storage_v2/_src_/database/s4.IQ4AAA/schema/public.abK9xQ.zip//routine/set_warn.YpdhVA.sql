create function set_warn() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
    -- пишем значения во вновь создаваемую запись
    IF (NEW.enddate > NEW.limitdate) THEN NEW.eventwindowstyle='s3_event_fail'; END IF;

    RETURN NEW;
END;
$$;

alter function set_warn() owner to postgres;

