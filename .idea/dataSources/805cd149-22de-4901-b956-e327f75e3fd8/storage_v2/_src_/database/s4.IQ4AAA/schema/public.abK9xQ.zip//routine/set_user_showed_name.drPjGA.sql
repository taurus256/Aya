create function set_user_showed_name() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
    NEW.showed_name=btrim(NEW.firstname) || ' ' || btrim(NEW.surname);	
    
    RETURN NEW;
END;
$$;

alter function set_user_showed_name() owner to postgres;

