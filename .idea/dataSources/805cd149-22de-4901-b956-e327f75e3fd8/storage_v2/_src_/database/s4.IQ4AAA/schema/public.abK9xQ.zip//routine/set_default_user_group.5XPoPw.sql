create function set_default_user_group() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
	INSERT INTO relation_user_group (userid,groupid) VALUES (NEW.id,0);
    RETURN NEW;
END;
$$;

alter function set_default_user_group() owner to postgres;

