create function set_event_duration() returns trigger
    language plpgsql
as
$$
DECLARE
    dow1 integer;
    dow2 integer;
    week1 integer;
    week2 integer;
    weekends integer;
    days integer;
    holyday_count integer default 0;
    short_count integer default 0;
BEGIN
    days := EXTRACT(DAY FROM NEW.enddate - NEW.startdate) +1;
    --извлекаем значения
    dow1 = EXTRACT(ISODOW FROM NEW.startdate);
    dow2 = EXTRACT(ISODOW FROM NEW.enddate);
    week1 = EXTRACT(WEEK FROM NEW.startdate);
    week2 = EXTRACT(WEEK FROM NEW.enddate);
    RAISE NOTICE 'dow1=% dow2=% week1=% week2=%', dow1, dow2, week1, week2;
 
    -- считаем количество выходных
    weekends = (week2 - week1)*2;
    
    IF dow2-5 > 0 THEN
        weekends = weekends + dow2 - 5;
    END IF;
    RAISE NOTICE 'weekends=%', weekends;
    -- считаем количество праздников и коротких дней
    SELECT COUNT(*) FROM holydays WHERE is_holyday=true AND date BETWEEN NEW.startdate AND NEW.enddate INTO holyday_count;
    SELECT COUNT(*) FROM holydays WHERE is_short=true AND date BETWEEN NEW.startdate AND NEW.enddate INTO short_count;
    
    -- пишем значения во вновь создаваемую запись
    NEW.duration_d := days - weekends - holyday_count;
    NEW.duration_h := (days - weekends - holyday_count) * 8 - short_count;

    RETURN NEW;
END;
$$;

alter function set_event_duration() owner to postgres;

