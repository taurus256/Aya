create function move_next_event() returns trigger
    language plpgsql
as
$$
DECLARE
deltadate interval;
super record;
BEGIN
	deltadate := NEW.startdate - OLD.startdate;
	--обновление связанной задачи
	UPDATE event SET startdate = NEW.enddate, enddate = NEW.enddate + (enddate - startdate) WHERE prev = NEW.id;
	--обновление всех "подлежащих" задач
	IF deltadate > '00:00:00' THEN
		UPDATE event SET startdate = startdate + deltadate, enddate = enddate + deltadate WHERE parent = NEW.id;
	END IF;
	--обновление "вышележащей" задачи, если надо
	SELECT * INTO super FROM event WHERE id = NEW.parent;
	IF FOUND THEN
		IF super.limitdate >= NEW.enddate THEN
			UPDATE event SET enddate = limitdate WHERE id = NEW.parent;
		ELSE
			UPDATE event SET enddate = NEW.enddate WHERE id = NEW.parent;
		END IF;
	END IF;
	
	RETURN NEW;
END;
$$;

alter function move_next_event() owner to postgres;

