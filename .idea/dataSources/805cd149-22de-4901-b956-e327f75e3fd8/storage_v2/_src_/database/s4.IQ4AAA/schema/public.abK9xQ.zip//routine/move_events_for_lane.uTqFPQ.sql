create function move_events_for_lane() returns trigger
    language plpgsql
as
$$
DECLARE parentLane RECORD;
BEGIN

	IF OLD.parent != NEW.parent THEN

		/*If lane is moved from lane level to sublane level*/
		IF OLD.parent = 0 THEN
			SELECT * INTO STRICT parentLane FROM lane WHERE id = NEW.parent;
			UPDATE event SET lane = parentLane.name, sublane = NEW.name WHERE lane = NEW.name;
			RETURN NEW;
		END IF;	

		/*If lane is moved  from sublane level to lane level*/
		IF NEW.parent = 0 THEN
			UPDATE event SET lane = NEW.name, sublane = NULL WHERE sublane = NEW.name;
			RETURN NEW;
		END IF;

		/*If lane is moved  from sublane level to sublane level (from one parent lane to another)*/
		SELECT * INTO STRICT parentLane FROM lane WHERE id = NEW.parent;
		UPDATE event SET lane = parentLane.name WHERE sublane = NEW.name;
		
	END IF;
	
    RETURN NEW;
    
END;
$$;

alter function move_events_for_lane() owner to postgres;

