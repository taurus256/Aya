create function set_document_content() returns trigger
    language plpgsql
as
$$
BEGIN
	-- если добавили документ - создаем ему запись в таблице содержимого
	IF NEW.type = 1 THEN
		INSERT INTO document_content (document_id, content) VALUES (NEW.id, 'DOCUMENT TEXT');
	END IF;

        RETURN NEW;
    END;
$$;

alter function set_document_content() owner to postgres;

