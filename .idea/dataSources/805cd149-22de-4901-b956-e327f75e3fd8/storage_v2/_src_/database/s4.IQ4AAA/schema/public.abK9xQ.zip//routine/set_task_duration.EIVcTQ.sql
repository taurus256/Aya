create function set_task_duration() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
	--NEW.duration := NEW.endtime - NEW.starttime;
	--arrange_right
	--UPDATE task SET starttime = NEW.endtime, endtime = starttime + duration WHERE id = NEW.next;
	--RAISE NOTICE 'UPDATED ID=%';	
	RETURN NEW;
END;
$$;

alter function set_task_duration() owner to postgres;

