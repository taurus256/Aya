create function arrange_right(i integer) returns integer
    language plpgsql
as
$$
DECLARE
 a integer;
 b integer;
 continuation timestamp;
 start_time timestamp;
 end_time timestamp;
BEGIN
	a := i;	
	RAISE NOTICE 'START RECORD ID=%', a;

	-- go to the next record
	SELECT next, starttime, endtime INTO a, start_time, end_time FROM task WHERE task.id = a;
	RAISE NOTICE 'VALUES=% , % , %', a, start_time, end_time;
	--RAISE NOTICE 'continuation=% ', continuation;
	-- modification of the next record (and all subsequent records)
	WHILE NOT a IS NULL LOOP
		UPDATE task SET starttime = end_time, endtime = end_time + duration WHERE id = a;
		RAISE NOTICE 'UPDATED ID=%', a;		
		SELECT next, starttime, endtime INTO a, start_time, end_time FROM task WHERE task.id = a;
	END LOOP;
	
	RETURN a;
END;
$$;

alter function arrange_right(integer) owner to postgres;

