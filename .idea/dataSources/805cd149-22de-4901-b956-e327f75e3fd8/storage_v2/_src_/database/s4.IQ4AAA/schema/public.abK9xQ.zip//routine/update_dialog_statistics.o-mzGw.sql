create function update_dialog_statistics() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
    UPDATE dialog SET  count = count + 1 WHERE id = NEW.dialog_id;
    UPDATE dialog_statistics SET count = count + 1 WHERE dialog_id = NEW.dialog_id AND user_id = NEW.sender_id;

   --	UPDATE event SET startdate = NEW.enddate, enddate = NEW.enddate + (enddate - startdate) WHERE prev = NEW.id;

    RETURN NEW;
END;
$$;

alter function update_dialog_statistics() owner to postgres;

