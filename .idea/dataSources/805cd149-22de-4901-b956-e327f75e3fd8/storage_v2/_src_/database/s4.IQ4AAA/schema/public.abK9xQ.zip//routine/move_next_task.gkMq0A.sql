create function move_next_task() returns trigger
    language plpgsql
as
$$
DECLARE
deltatime interval;
BEGIN
	deltatime := NEW.starttime - OLD.starttime;
	--обновление связанной задачи
	UPDATE task SET starttime = NEW.endtime, endtime = NEW.endtime + duration WHERE id = NEW.next;
	--обновление всех "подлежащих" задач
	IF deltatime > '00:00:00' THEN
		UPDATE task SET starttime = starttime + deltatime, endtime = endtime + deltatime WHERE parent = NEW.id;
	END IF;
	--обновление "вышележащей" задачи, если надо
	UPDATE task SET endtime = NEW.endtime WHERE id = NEW.parent AND endtime <= NEW.endtime;
	RETURN NEW;
END;
$$;

alter function move_next_task() owner to postgres;

